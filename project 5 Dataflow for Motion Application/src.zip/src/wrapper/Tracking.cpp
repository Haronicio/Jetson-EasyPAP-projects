/*
  ALBISSON Damien
  DAUVET-DIAKHATE Haron
*/

#include "motion/wrapper/Tracking.hpp"

Tracking::Tracking(const int max_size_RoI, 
    const int p_trk_ext_d, const int p_trk_obj_min, const bool has_visu, const int p_trk_ext_o, 
    const int p_knn_s): Module(), max_size_RoI(max_size_RoI), p_trk_ext_d(p_trk_ext_d), p_trk_obj_min(p_trk_obj_min),
    has_visu(has_visu), p_trk_ext_o(p_trk_ext_o), p_knn_s(p_knn_s) { 
    
    const std::string name = "Tracking";
    this->set_name(name);
    this->set_short_name(name);
    this->tracking_data = tracking_alloc_data(MAX(p_trk_obj_min, p_trk_ext_o) + 1, max_size_RoI);
    tracking_init_data(this->tracking_data);

    auto &t = this->create_task("Tracking_perform");

    auto si_n_RoIs1 = this->template create_socket_in<uint32_t>(t, "in_n_RoIs1", 1);
    auto si_RoIs1 = this->template create_socket_in<uint8_t>(t, "in_RoIs1", max_size_RoI * sizeof(RoI_t));
    auto si_cur_frame = this->template create_socket_in<uint32_t>(t, "in_cur_frame", 1);

    auto so_cur_frame = this->template create_socket_out<uint32_t>(t, "out_cur_frame", 1);

    this->create_codelet(t, [si_n_RoIs1, si_RoIs1, si_cur_frame, so_cur_frame]
                (Module &m, runtime::Task &t, const size_t frame_id) -> int {
        Tracking &mt = static_cast<Tracking&>(m);

        tracking_perform(mt.tracking_data, (RoI_t*) (t[si_RoIs1].get_dataptr<uint8_t>()), (size_t)(*(t[si_n_RoIs1].get_dataptr<uint32_t>())),
            (size_t)(*(t[si_cur_frame].get_dataptr<uint32_t>())), mt.p_trk_ext_d, mt.p_trk_obj_min, mt.has_visu, mt.p_trk_ext_o, mt.p_knn_s);

        (*(t[so_cur_frame].get_dataptr<uint32_t>())) = (*(t[si_cur_frame].get_dataptr<uint32_t>()));

        return aff3ct::runtime::status_t::SUCCESS;
    });
}

Tracking::~Tracking() {
    tracking_free_data(this->tracking_data);
}

tracking_data_t* Tracking::get_data() {
    return this->tracking_data;
}