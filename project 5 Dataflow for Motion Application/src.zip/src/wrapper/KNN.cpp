/*
  ALBISSON Damien
  DAUVET-DIAKHATE Haron
*/

#include "motion/wrapper/KNN.hpp"

KNN::KNN(const int max_size_RoI, const int p_knn_k, 
    const int p_knn_d, const int p_knn_s): Module(), max_size_RoI(max_size_RoI), 
    p_knn_k(p_knn_k), p_knn_d(p_knn_d), p_knn_s(p_knn_s) { 
    
    const std::string name = "KNN";
    this->set_name(name);
    this->set_short_name(name);
    this->kNN_data = kNN_alloc_data(max_size_RoI);
    kNN_init_data(this->kNN_data);

    auto &t = this->create_task("KNN_match");

    auto si_n_RoIs0 = this->template create_socket_in<uint32_t>(t, "in_n_RoIs0", 1);
    auto si_RoIs0 = this->template create_socket_in<uint8_t>(t, "in_RoIs0", max_size_RoI * sizeof(RoI_t));
    auto si_n_RoIs1= this->template create_socket_in<uint32_t>(t, "in_n_RoIs1", 1);
    auto si_RoIs1 = this->template create_socket_in<uint8_t>(t, "in_RoIs1", max_size_RoI * sizeof(RoI_t));

    auto so_RoIs1 = this->template create_socket_out<uint8_t>(t, "out_RoIs1", max_size_RoI * sizeof(RoI_t));
    auto so_RoIs0 = this->template create_socket_out<uint8_t>(t, "out_RoIs0", max_size_RoI * sizeof(RoI_t));
    /*
    auto so_nearest = this->template create_socket_out<uint32_t>(t, "out_nearest", 1);
    auto so_distances = this->template create_socket_out<float>(t, "out_distances", 1);
    */
   
    this->create_codelet(t, [si_n_RoIs0, si_RoIs0, si_n_RoIs1, si_RoIs1, so_RoIs1, so_RoIs0]
                (Module &m, runtime::Task &t, const size_t frame_id) -> int {
        KNN &mKNN = static_cast<KNN&>(m);

        kNN_match(mKNN.kNN_data, (RoI_t*) (t[si_RoIs0].get_dataptr<uint8_t>()), (size_t)(*(t[si_n_RoIs0].get_dataptr<uint32_t>())), 
            (RoI_t*) (t[si_RoIs1].get_dataptr<uint8_t>()), (size_t)(*(t[si_n_RoIs1].get_dataptr<uint32_t>())), 
            mKNN.p_knn_k, mKNN.p_knn_d, mKNN.p_knn_s);

        uint8_t* ptr_so_RoIs1 = t[so_RoIs1].get_dataptr<uint8_t>();
        memcpy(ptr_so_RoIs1, t[si_RoIs1].get_dataptr<uint32_t>(), mKNN.max_size_RoI * sizeof(RoI_t));  

        uint8_t* ptr_so_RoIs0 = t[so_RoIs0].get_dataptr<uint8_t>();
        memcpy(ptr_so_RoIs0, t[si_RoIs0].get_dataptr<uint32_t>(), mKNN.max_size_RoI * sizeof(RoI_t));  

        return aff3ct::runtime::status_t::SUCCESS;
    });
}

KNN::~KNN() {
    kNN_free_data(this->kNN_data);
}

kNN_data_t* KNN::get_data() {
    return this->kNN_data;
}