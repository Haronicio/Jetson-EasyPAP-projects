/*
  ALBISSON Damien
  DAUVET-DIAKHATE Haron
*/

#include "motion/wrapper/Feature_filter.hpp"

Feature_filter::Feature_filter(const int i0, const int i1, const int j0, const int j1, 
    const int max_size_RoI_tmp, const int max_size_RoI, const int p_flt_s_min, const int p_flt_s_max, const bool label2_is_null): Module(), i0(i0), 
    i1(i1), j0(j0), j1(j1), max_size_RoI_tmp(max_size_RoI_tmp), max_size_RoI(max_size_RoI), p_flt_s_min(p_flt_s_min), p_flt_s_max(p_flt_s_max),
    label2_is_null(label2_is_null)  { 
    
    const std::string name = "Feature_filter";
    this->set_name(name);
    this->set_short_name(name);

    auto &t = this->create_task("Feature_filter_filter");

    auto socket_img_size = ((i1 - i0) + 1) * ((j1 - j0) + 1);

    auto si_labels1_in = this->template create_socket_in<uint32_t>(t, "in_labels1", socket_img_size);
    auto si_RoIs_tmp = this->template create_socket_in<uint8_t>(t, "in_RoIs_tmp", max_size_RoI_tmp * sizeof(RoI_t));
    auto si_n_RoIs_tmp = this->template create_socket_in<uint32_t>(t, "in_n_RoIs_tmp", 1);
    // auto si_RoIs = this->template create_socket_in<uint8_t>(t, "in_RoIs", max_size_RoI * sizeof(RoI_t));

    // size of labels equals to the size of img
    auto so_RoIs = this->template create_socket_out<uint8_t>(t, "out_RoIs", max_size_RoI * sizeof(RoI_t));
    auto so_n_RoIs = this->template create_socket_out<uint32_t>(t, "out_n_RoIs", 1);

    this->create_codelet(t, [si_labels1_in, si_RoIs_tmp, si_n_RoIs_tmp, so_RoIs, so_n_RoIs]
                (Module &m, runtime::Task &t, const size_t frame_id) -> int {
        Feature_filter &mFf = static_cast<Feature_filter&>(m);
        

        *(t[so_n_RoIs].get_dataptr<uint32_t>()) = features_filter_surface((const uint32_t**) (t[si_labels1_in].get_dataptr<uint32_t>()), 
            NULL, mFf.i0, mFf.i1, mFf.j0, mFf.j1, 
            (RoI_t*) (t[si_RoIs_tmp].get_dataptr<uint8_t>()), (size_t) (*(t[si_n_RoIs_tmp].get_dataptr<uint32_t>())), 
            mFf.p_flt_s_min, mFf.p_flt_s_max);

        // assert(n_RoIs0 <= (uint32_t)p_cca_roi_max2);
        // features_labels_zero_init(RoIs_tmp->basic, L1);
        features_shrink_basic((RoI_t*) (t[si_RoIs_tmp].get_dataptr<uint8_t>()), (size_t) (*(t[si_n_RoIs_tmp].get_dataptr<uint32_t>())), 
            (RoI_t*) (t[so_RoIs].get_dataptr<uint8_t>()));

        return aff3ct::runtime::status_t::SUCCESS;
    });
}