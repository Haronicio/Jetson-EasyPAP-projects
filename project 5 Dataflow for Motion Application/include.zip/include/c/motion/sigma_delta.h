#pragma once

#include "motion/sigma_delta/sigma_delta_struct.h"
#include "motion/sigma_delta/sigma_delta_compute.h"
