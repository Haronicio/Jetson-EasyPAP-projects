#pragma once

#include "motion/morpho/morpho_struct.h"
#include "motion/morpho/morpho_compute.h"
