/*
  ALBISSON Damien
  DAUVET-DIAKHATE Haron
*/

#pragma once

#include <stdint.h>
#include <aff3ct-core.hpp>

#include "motion/tools.h"
#include "motion/CCL/CCL_struct.h"
#include "motion/CCL/CCL_compute.h"

using namespace aff3ct;
using namespace aff3ct::module;

class CCL : public aff3ct::module::Module, public tools::Interface_is_done {
protected:
    CCL_data_t* CCL_data;
    const int i0;
    const int i1;
    const int j0;
    const int j1;
    uint8_t** img_in;
    uint32_t** labels_out;

public:
    CCL(const int i0, const int i1, const int j0, const int j1);
    ~CCL();
    virtual bool is_done() const {
        return false;
    }
};
