/*
  ALBISSON Damien
  DAUVET-DIAKHATE Haron
*/

#pragma once

#include <stdint.h>
#include <aff3ct-core.hpp>

#include "motion/tools.h"
#include "motion/sigma_delta/sigma_delta_struct.h"
#include "motion/sigma_delta/sigma_delta_compute.h"

using namespace aff3ct;
using namespace aff3ct::module;

class Sigma_delta : public aff3ct::module::Module, public tools::Interface_is_done {
protected:
    sigma_delta_data_t* sigma_delta_data;
    const uint8_t** IG1;
    const int i0;
    const int i1;
    const int j0;
    const int j1;
    const uint8_t N;
    uint8_t** img_out;
    uint8_t** img_in;

public:
    Sigma_delta(const uint8_t** IG1, const int i0, const int i1, const int j0, const int j1, const uint8_t N);
    ~Sigma_delta();
    virtual bool is_done() const {
        return false;
    }
};
