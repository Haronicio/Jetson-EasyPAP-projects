/*!
 * \file
 * \brief Video module (read and write).
 */

#pragma once

#include "motion/video/video_struct.h"
#include "motion/video/video_io.h"
