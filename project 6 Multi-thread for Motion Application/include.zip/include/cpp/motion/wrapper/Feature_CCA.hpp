/*
  ALBISSON Damien
  DAUVET-DIAKHATE Haron
*/

#pragma once

#include <stdint.h>
#include <aff3ct-core.hpp>

#include "motion/tools.h"
#include "motion/features/features_struct.h"
#include "motion/features/features_compute.h"

using namespace aff3ct;
using namespace aff3ct::module;

class Feature_CCA : public aff3ct::module::Module, public tools::Interface_is_done {
protected:
    const int i0;
    const int i1;
    const int j0;
    const int j1;
    const int max_size_RoI;
    uint32_t** labels_in;

public:
    Feature_CCA(const int i0, const int i1, const int j0, const int j1, const int max_size_RoI);
    virtual bool is_done() const {
        return false;
    }
    Feature_CCA* clone() const;
    void deep_copy(const Feature_CCA& m);
};
