/*
  ALBISSON Damien
  DAUVET-DIAKHATE Haron
*/

#pragma once

#include <stdint.h>
#include <aff3ct-core.hpp>

#include "motion/macros.h"
#include "motion/tools.h"
#include "motion/tracking/tracking_struct.h"
#include "motion/tracking/tracking_compute.h"

using namespace aff3ct;
using namespace aff3ct::module;

class Tracking : public aff3ct::module::Module, public tools::Interface_is_done {
protected:
    tracking_data_t* tracking_data;
    const int max_size_RoI;
    const int p_trk_ext_d;
    const int p_trk_obj_min;
    const bool has_visu;
    const int p_trk_ext_o;
    const int p_knn_s;

public:
    Tracking(const int max_size_RoI, const int p_trk_ext_d, 
        const int p_trk_obj_min, const bool has_visu, const int p_trk_ext_o, const int p_knn_s);
    ~Tracking();
    tracking_data_t* get_data();
    virtual bool is_done() const {
        return false;
    }
};
