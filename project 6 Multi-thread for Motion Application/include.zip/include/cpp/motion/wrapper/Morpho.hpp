/*
  ALBISSON Damien
  DAUVET-DIAKHATE Haron
*/

#pragma once

#include <stdint.h>
#include <aff3ct-core.hpp>

#include "motion/tools.h"
#include "motion/morpho/morpho_struct.h"
#include "motion/morpho/morpho_compute.h"

using namespace aff3ct;
using namespace aff3ct::module;

class Morpho : public aff3ct::module::Module, public tools::Interface_is_done {
protected:
    morpho_data_t* morpho_data;
    const int i0;
    const int i1;
    const int j0;
    const int j1;
    uint8_t** img_out;
    uint8_t** img_in;

public:
    Morpho(const int i0, const int i1, const int j0, const int j1);
    ~Morpho();
    virtual bool is_done() const {
        return false;
    }
    Morpho* clone() const;
    void deep_copy(const Morpho& m);
};
