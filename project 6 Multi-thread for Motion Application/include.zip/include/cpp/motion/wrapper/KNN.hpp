/*
  ALBISSON Damien
  DAUVET-DIAKHATE Haron
*/

#pragma once

#include <stdint.h>
#include <aff3ct-core.hpp>

#include "motion/tools.h"
#include "motion/kNN/kNN_struct.h"
#include "motion/kNN/kNN_compute.h"

using namespace aff3ct;
using namespace aff3ct::module;

class KNN : public aff3ct::module::Module, public tools::Interface_is_done {
protected:
    kNN_data_t* kNN_data;
    const int max_size_RoI;
    const int p_knn_k;
    const int p_knn_d;
    const int p_knn_s;

public:
    KNN(const int max_sizeRoI, const int p_knn_k, const int p_knn_d, const int p_knn_s);
    ~KNN();
    kNN_data_t* get_data();
    virtual bool is_done() const {
        return false;
    }
    KNN* clone() const;
    void deep_copy(const KNN& m);
};
