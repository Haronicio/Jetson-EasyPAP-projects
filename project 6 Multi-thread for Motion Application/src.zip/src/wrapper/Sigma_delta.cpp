/*
  ALBISSON Damien
  DAUVET-DIAKHATE Haron
*/

#include "motion/wrapper/Sigma_delta.hpp"

Sigma_delta::Sigma_delta(const uint8_t** IG1, const int i0, const int i1,
    const int j0, const int j1, const uint8_t N): Module(), IG1(IG1), i0(i0), i1(i1), j0(j0), j1(j1), N(N) { 
    
    const std::string name = "Sigma_delta";
    this->set_name(name);
    this->set_short_name(name);
    this->sigma_delta_data = sigma_delta_alloc_data(i0, i1, j0, j1, 1, 254);
    sigma_delta_init_data(this->sigma_delta_data, this->IG1, i0, i1, j0, j1);

    auto &t = this->create_task("sigma_delta_compute");

    auto socket_img_size = ((i1 - i0) + 1) * ((j1 - j0) + 1);

    this->img_out = (uint8_t**)malloc((size_t)(socket_img_size) * sizeof(uint8_t*));
    this->img_in = (uint8_t**)malloc((size_t)(socket_img_size) * sizeof(uint8_t*));

    // think about the size of img
    auto si_img_in = this->template create_socket_in<uint8_t>(t, "in_img", socket_img_size);
    auto so_img_out = this->template create_socket_out<uint8_t>(t, "out_img", socket_img_size);

    this->create_codelet(t, [si_img_in, so_img_out](Module &m, runtime::Task &t, const size_t frame_id) -> int {
        Sigma_delta &msd = static_cast<Sigma_delta&>(m);

        tools_linear_2d_nrc_ui8matrix((const uint8_t*)t[so_img_out].get_dataptr<uint8_t>(),
                                      msd.i0, msd.i1, msd.j0, msd.j1,
                                      (const uint8_t**)msd.img_out);


        uint8_t* in_img = t[si_img_in].get_dataptr<uint8_t>();
        tools_linear_2d_nrc_ui8matrix((const uint8_t*)in_img,
                                      msd.i0, msd.i1, msd.j0, msd.j1,
                                      (const uint8_t**)msd.img_in);

        sigma_delta_compute2(msd.sigma_delta_data, (const uint8_t**)msd.img_in,
            msd.img_out, msd.i0, msd.i1, msd.j0, msd.j1, msd.N);

        return aff3ct::runtime::status_t::SUCCESS;
    });
}

Sigma_delta::~Sigma_delta() {
    sigma_delta_free_data(this->sigma_delta_data);
}