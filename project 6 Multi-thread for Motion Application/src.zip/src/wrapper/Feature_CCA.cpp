/*
  ALBISSON Damien
  DAUVET-DIAKHATE Haron
*/

#include "motion/wrapper/Feature_CCA.hpp"

Feature_CCA::Feature_CCA(const int i0, const int i1,
    const int j0, const int j1, const int max_size_RoI): Module(), i0(i0), i1(i1), j0(j0), j1(j1), max_size_RoI(max_size_RoI) { 
    
    const std::string name = "Feature_CCA";
    this->set_name(name);
    this->set_short_name(name);

    auto &t = this->create_task("Feature_CCA_extract");

    auto socket_img_size = ((i1 - i0) + 1) * ((j1 - j0) + 1);

    this->labels_in = (uint32_t**)malloc((size_t)(socket_img_size) * sizeof(uint32_t*));

    // think about the size of img
    auto si_labels_in = this->template create_socket_in<uint32_t>(t, "in_labels", socket_img_size);
    auto si_n_RoIs_tmp0 = this->template create_socket_in<uint32_t>(t, "in_n_RoIs_tmp0", 1);
    // auto si_RoIs = this->template create_socket_in<uint8_t>(t, "in_RoIs_tmp", max_size_RoI * sizeof(RoI_t));

    // size of labels equals to the size of img
    auto so_RoIs_tmp = this->template create_socket_out<uint8_t>(t, "out_RoIs_tmp", max_size_RoI * sizeof(RoI_t));

    this->create_codelet(t, [si_labels_in, si_n_RoIs_tmp0, so_RoIs_tmp]
                (Module &m, runtime::Task &t, const size_t frame_id) -> int {
        Feature_CCA &mFCCA = static_cast<Feature_CCA&>(m);

        tools_linear_2d_nrc_ui32matrix((const uint32_t*)t[si_labels_in].get_dataptr<uint8_t>(),
                                      mFCCA.i0, mFCCA.i1, mFCCA.j0, mFCCA.j1,
                                      (const uint32_t**)mFCCA.labels_in);


        features_extract((const uint32_t**)mFCCA.labels_in, mFCCA.i0, mFCCA.i1, mFCCA.j0, mFCCA.j1, 
            (RoI_t*) (t[so_RoIs_tmp].get_dataptr<uint8_t>()),(size_t) (*(t[si_n_RoIs_tmp0].get_dataptr<uint32_t>())));


        return aff3ct::runtime::status_t::SUCCESS;
    });
}

Feature_CCA* Feature_CCA::clone() const {
    auto m = new Feature_CCA(*this);
    m->deep_copy(*this); // we override this method just after
    return m;
}

// in the deep_copy method, 'this' is the newly allocated object while 'm' is the former object
void Feature_CCA::deep_copy(const Feature_CCA& m) {
    Module::deep_copy(m);
    auto socket_img_size = ((m.i1 - m.i0) + 1) * ((m.j1 - m.j0) + 1);
    this->labels_in = (uint32_t**)malloc((size_t)(socket_img_size) * sizeof(uint32_t*));
}