/*
  ALBISSON Damien
  DAUVET-DIAKHATE Haron
*/

#include "motion/wrapper/CCL.hpp"

CCL::CCL(const int i0, const int i1, const int j0, const int j1): Module(), 
    i0(i0), i1(i1), j0(j0), j1(j1) { 
    
    const std::string name = "CCL";
    this->set_name(name);
    this->set_short_name(name);
    this->CCL_data = CCL_LSL_alloc_data(i0, i1, j0, j1);
    CCL_LSL_init_data(this->CCL_data);

    auto &t = this->create_task("CCL_apply");

    auto socket_img_size = ((i1 - i0) + 1) * ((j1 - j0) + 1);

    this->img_in = (uint8_t**)malloc((size_t)(socket_img_size) * sizeof(uint8_t*));
    this->labels_out = (uint32_t**)malloc((size_t)(socket_img_size) * sizeof(uint32_t*));

    // think about the size of img
    auto si_img_in = this->template create_socket_in<uint8_t>(t, "in_img", socket_img_size);

    // size of labels equals to the size of img
    auto so_labels_out = this->template create_socket_out<uint32_t>(t, "out_labels", socket_img_size);
    auto so_n_RoIs_tmp0 = this->template create_socket_out<uint32_t>(t, "out_n_RoIs_tmp0", 1);

    this->create_codelet(t, [si_img_in, so_labels_out, so_n_RoIs_tmp0](Module &m, runtime::Task &t, const size_t frame_id) -> int {
        CCL &mCCL = static_cast<CCL&>(m);

        tools_linear_2d_nrc_ui8matrix((const uint8_t*)t[si_img_in].get_dataptr<uint8_t>(),
                                      mCCL.i0, mCCL.i1, mCCL.j0, mCCL.j1,
                                      (const uint8_t**)mCCL.img_in);

        tools_linear_2d_nrc_ui32matrix((const uint32_t*)t[so_labels_out].get_dataptr<uint8_t>(),
                                      mCCL.i0, mCCL.i1, mCCL.j0, mCCL.j1,
                                      (const uint32_t**)mCCL.labels_out);

        /*
        *(t[so_n_RoIs_tmp0].get_dataptr<uint32_t>()) = CCL_LSL_apply(mCCL.CCL_data, 
            (const uint8_t**)(t[si_img_in].get_dataptr<uint8_t>()), (uint32_t**)(t[so_labels_out].get_dataptr<uint32_t>()), 0);
        */

        *(t[so_n_RoIs_tmp0].get_dataptr<uint32_t>()) = (uint32_t)(CCL_LSL_apply(mCCL.CCL_data, 
            (const uint8_t**)mCCL.img_in, mCCL.labels_out, 0));

        return aff3ct::runtime::status_t::SUCCESS;
    });
}

CCL::~CCL() {
    CCL_LSL_free_data(this->CCL_data);
}

CCL* CCL::clone() const {
    auto m = new CCL(*this);
    m->deep_copy(*this); // we override this method just after
    return m;
}

// in the deep_copy method, 'this' is the newly allocated object while 'm' is the former object
void CCL::deep_copy(const CCL& m) {
    // call the 'deep_copy' method of the Module class
    Module::deep_copy(m);
    // simply copy the 'i0, i1, j0, j1' variables to have shorter names later in the method
    int i0 = m.CCL_data->i0, i1 = m.CCL_data->i1;
    int j0 = m.CCL_data->j0, j1 = m.CCL_data->j1;
    // allocate new morpho inner data
    this->CCL_data = CCL_LSL_alloc_data(i0, i1, j0, j1);
    // initialize the previously allocated data
    CCL_LSL_init_data(this->CCL_data);
    // allocate the 2D containers for converting 1D to 2D images in the task
    this->img_in = (uint8_t**)malloc((size_t)(((i1 - i0) + 1) * sizeof(const uint8_t*)));
    this->img_in -= i0;
    auto socket_img_size = ((i1 - i0) + 1) * ((j1 - j0) + 1);
    this->labels_out = (uint32_t**)malloc((size_t)(socket_img_size) * sizeof(uint32_t*));
}