/*
  ALBISSON Damien
  DAUVET-DIAKHATE Haron
*/

#include "motion/wrapper/Morpho.hpp"

Morpho::Morpho(const int i0, const int i1, const int j0, const int j1): Module(), 
    i0(i0), i1(i1), j0(j0), j1(j1) { 
    
    const std::string name = "Morpho";
    this->set_name(name);
    this->set_short_name(name);
    this->morpho_data = morpho_alloc_data(i0, i1, j0, j1);
    morpho_init_data(this->morpho_data);

    auto &t = this->create_task("morpho_compute");

    auto socket_img_size = ((i1 - i0) + 1) * ((j1 - j0) + 1);
    this->img_in = (uint8_t**)malloc((size_t)(socket_img_size) * sizeof(uint8_t*));
    this->img_out = (uint8_t**)malloc((size_t)(socket_img_size) * sizeof(uint8_t*));

    // think about the size of img
    auto si_img_in = this->template create_socket_in<uint8_t>(t, "in_img", socket_img_size);
    auto so_img_out = this->template create_socket_out<uint8_t>(t, "out_img", socket_img_size);

    this->create_codelet(t, [si_img_in, so_img_out](Module &m, runtime::Task &t, const size_t frame_id) -> int {
        Morpho &mm = static_cast<Morpho&>(m);

        tools_linear_2d_nrc_ui8matrix((const uint8_t*)t[si_img_in].get_dataptr<uint8_t>(),
                                      mm.i0, mm.i1, mm.j0, mm.j1,
                                      (const uint8_t**)mm.img_in);
        
        /*
        printf("morpho matrix in : \n");
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 30; j++) {
                printf("%d, ", mm.img_in[i][j]);
            }
            printf("\n");
        }
        */
        

        tools_linear_2d_nrc_ui8matrix((const uint8_t*)t[so_img_out].get_dataptr<uint8_t>(),
                                      mm.i0, mm.i1, mm.j0, mm.j1,
                                      (const uint8_t**)mm.img_out);

        morpho_compute_opening3(mm.morpho_data, (const uint8_t**)mm.img_in,
            mm.img_out, mm.i0, mm.i1, mm.j0, mm.j1);
        morpho_compute_closing3(mm.morpho_data, (const uint8_t**)mm.img_in,
            mm.img_out, mm.i0, mm.i1, mm.j0, mm.j1);
        /*
        printf("morpho matrix out : \n");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 30; j++) {
                printf("%d, ", mm.img_out[i][j]);
            }
            printf("\n");
        }
        */

        
        return aff3ct::runtime::status_t::SUCCESS;
    });
}

Morpho::~Morpho() {
    morpho_free_data(this->morpho_data);
}

Morpho* Morpho::clone() const {
    auto m = new Morpho(*this);
    m->deep_copy(*this); // we override this method just after
    return m;
}

// in the deep_copy method, 'this' is the newly allocated object while 'm' is the former object
void Morpho::deep_copy(const Morpho& m) {
    // call the 'deep_copy' method of the Module class
    Module::deep_copy(m);
    // simply copy the 'i0, i1, j0, j1' variables to have shorter names later in the method
    int i0 = m.morpho_data->i0, i1 = m.morpho_data->i1;
    int j0 = m.morpho_data->j0, j1 = m.morpho_data->j1;
    // allocate new morpho inner data
    this->morpho_data = morpho_alloc_data(i0, i1, j0, j1);
    // initialize the previously allocated data
    morpho_init_data(this->morpho_data);
    // allocate the 2D containers for converting 1D to 2D images in the task
    this->img_in = (uint8_t**)malloc((size_t)(((i1 - i0) + 1) * sizeof(const uint8_t*)));
    this->img_in -= i0;
    this->img_out = (uint8_t**)malloc((size_t)(((i1 - i0) + 1) * sizeof(uint8_t*)));
    this->img_out -= i0;
}