#include <math.h>
#include <stdlib.h>
#include <nrc2.h>
#include <omp.h>
#include <stdio.h>
#include <cstring>
#include "../../../lib/mipp/src/mipp.h"

#include "motion/macros.h"
#include "motion/sigma_delta/sigma_delta_compute2.hpp"

void sigma_delta_compute2(sigma_delta_data_t *sd_data, const uint8_t** img_in, uint8_t** img_out, const int i0,
                         const int i1, const int j0, const int j1, const uint8_t N) {

    /*
    mipp::Reg<int16_t> r_data_M;
    mipp::Reg<int16_t> r_img_in;

    for (int i = i0; i <= i1; i++) {
        for (int j = j0; j <= j1; j++) {
            uint8_t new_m = sd_data->M[i][j];
            if (sd_data->M[i][j] < img_in[i][j])
                new_m += 1;
            else if (sd_data->M[i][j] > img_in[i][j])
                new_m -= 1;
            sd_data->M[i][j] = new_m;
        }
    }
    
    for (int i = i0; i <= i1; i++) {
        for (int j = j0; j <= (j1 - (j1% mipp::N<int16_t>())); j+=mipp::N<int16_t>()) {
            r_data_M.load((const int16_t*) (&(sd_data->M[i][j])));
            r_img_in.load((const int16_t*) (&(img_in[i][j])));
            mipp::abs(r_data_M - r_img_in).store((int16_t*) (&(sd_data->O[i][j])));
        }
        for (int j = j1 - (j1% mipp::N<int16_t>()); j <= j1; j++) {
            sd_data->O[i][j] = abs(sd_data->M[i][j] - img_in[i][j]);
        }
    }

    for (int i = i0; i <= i1; i++) {
        for (int j = j0; j <= j1; j++) {
            uint8_t new_v = sd_data->V[i][j];
            if (sd_data->V[i][j] < N * sd_data->O[i][j])
                new_v += 1;
            else if (sd_data->V[i][j] > N * sd_data->O[i][j])
                new_v -= 1;
            sd_data->V[i][j] = MAX(MIN(new_v, sd_data->vmax), sd_data->vmin);
        }
    }

    for (int i = i0; i <= i1; i++) {
        for (int j = j0; j <= j1; j++) {
            img_out[i][j] = sd_data->O[i][j] < sd_data->V[i][j] ? 0 : 255;
        }
    }
    */
    
    #pragma omp parallel 
    {
        #pragma omp for schedule(runtime) collapse(2)
        for (int i = i0; i <= i1; i++) {
            for (int j = j0; j <= j1; j++) {
                uint8_t new_m = sd_data->M[i][j];
                if (sd_data->M[i][j] < img_in[i][j])
                    new_m += 1;
                else if (sd_data->M[i][j] > img_in[i][j])
                    new_m -= 1;
                sd_data->M[i][j] = new_m;
            }
        }

        #pragma omp for schedule(runtime) collapse(2)
        for (int i = i0; i <= i1; i++) {
            for (int j = j0; j <= j1; j++) {
                sd_data->O[i][j] = abs(sd_data->M[i][j] - img_in[i][j]);
            }
        }

        #pragma omp for schedule(runtime) collapse(2)
        for (int i = i0; i <= i1; i++) {
            for (int j = j0; j <= j1; j++) {
                uint8_t new_v = sd_data->V[i][j];
                if (sd_data->V[i][j] < N * sd_data->O[i][j])
                    new_v += 1;
                else if (sd_data->V[i][j] > N * sd_data->O[i][j])
                    new_v -= 1;
                sd_data->V[i][j] = MAX(MIN(new_v, sd_data->vmax), sd_data->vmin);
            }
        }

        #pragma omp for schedule(runtime) collapse(2)
        for (int i = i0; i <= i1; i++) {
            for (int j = j0; j <= j1; j++) {
                img_out[i][j] = sd_data->O[i][j] < sd_data->V[i][j] ? 0 : 255;
            }
        }
    }
}
